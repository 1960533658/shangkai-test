let oSpan = document.querySelectorAll("span")
let cDiv = document.querySelectorAll(".context div")

// 选项按钮切换
for (i = 0; i < oSpan.length; i++) {
  oSpan[i].index = i

  oSpan[i].addEventListener("click", function Switch() {
    for (y = 0; y < oSpan.length; y++) {
      oSpan[y].classList.remove("check")
      cDiv[y].className = ""
    }
    this.classList.add("check")
    cDiv[this.index].className = "show"
  })
}